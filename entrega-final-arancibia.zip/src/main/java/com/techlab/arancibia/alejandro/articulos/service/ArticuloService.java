
package com.techlab.arancibia.alejandro.articulos.service;

import com.techlab.arancibia.alejandro.articulos.model.Articulo;

import java.util.List;

public interface ArticuloService {
    Articulo obtenerArticuloPorId(Long id);
    Articulo guardarArticulo(Articulo articulo);
    Articulo actualizarArticulo(Long id, Articulo articulo);
    void eliminarArticulo(Long id);
    List<Articulo> buscarConFiltros(Articulo articulo);
}
