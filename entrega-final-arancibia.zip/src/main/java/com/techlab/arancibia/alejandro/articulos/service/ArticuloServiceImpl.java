
package com.techlab.arancibia.alejandro.articulos.service;

import com.techlab.arancibia.alejandro.articulos.model.Articulo;
import com.techlab.arancibia.alejandro.articulos.repository.ArticuloRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ArticuloServiceImpl implements ArticuloService {

    private final ArticuloRepository articuloRepository;

    private static final String NOT_FOUND_MENSAJE  = "No se encontró ningun artículo.";

    public Articulo obtenerArticuloPorId(Long id) {

        return articuloRepository.findById(id)
                .orElseThrow(() -> new RuntimeException(NOT_FOUND_MENSAJE));
    }

    public Articulo guardarArticulo(Articulo articulo) {
        return articuloRepository.save(articulo);
    }

    public Articulo actualizarArticulo(Long id, Articulo articulo) {
        Articulo articuloAActualizar = obtenerArticuloPorId(id);
        // Se valida que tenga algo para actualizar
        if (noEsNulo(articulo.getNombre())) articuloAActualizar.setNombre(articulo.getNombre());
        if (noEsNulo(articulo.getPrecio())) articuloAActualizar.setPrecio(articulo.getPrecio());

        return articuloRepository.save(articuloAActualizar);
    }

    public void eliminarArticulo(Long id) {
        Articulo articulo = obtenerArticuloPorId(id);
        articuloRepository.deleteById(id);
    }

    @Override
    public List<Articulo> buscarConFiltros(Articulo articulo) {
        ExampleMatcher matcher = ExampleMatcher.matching()
                .withIgnoreCase()
                .withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING);
        Example<Articulo> ejemplo = Example.of(articulo, matcher);
        List<Articulo> articulos = articuloRepository.findAll(ejemplo);
        if (articulos.isEmpty()){
            throw new RuntimeException(NOT_FOUND_MENSAJE);
        }
        return  articulos;
    }

    private boolean noEsNulo(Object campo){
        return campo != null;
    }
}
