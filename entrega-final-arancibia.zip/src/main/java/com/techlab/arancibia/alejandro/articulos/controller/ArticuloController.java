package com.techlab.arancibia.alejandro.articulos.controller;

import com.techlab.arancibia.alejandro.articulos.model.Articulo;
import com.techlab.arancibia.alejandro.articulos.service.ArticuloService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/articulos") // Ruta base
@RequiredArgsConstructor
public class ArticuloController {

    private final ArticuloService articuloService;

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public List<Articulo> buscarConFiltros(Articulo filtro) {
        return articuloService.buscarConFiltros(filtro);
    }

    @GetMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Articulo obtenerPorId(@PathVariable Long id) {
        return articuloService.obtenerArticuloPorId(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Articulo crear(@RequestBody Articulo articulo) {
        return articuloService.guardarArticulo(articulo);
    }

    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Articulo actualizar(@PathVariable Long id, @RequestBody Articulo articulo) {
        return articuloService.actualizarArticulo(id, articulo);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminar(@PathVariable Long id) {
        articuloService.eliminarArticulo(id);
    }
}